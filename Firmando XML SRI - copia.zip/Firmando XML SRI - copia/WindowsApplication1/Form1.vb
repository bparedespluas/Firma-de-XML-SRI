﻿'Imports MySql.Data
'Imports MySql.Data.MySqlClient.MySqlParameterCollection
'Imports MySql.Data.Types
'Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.IO.File
Imports ComprobantesElectronicos

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objetoEntrada As ComprobantesElectronicos.ParametrosEntradaFirma = New ParametrosEntradaFirma()
        Dim objetoFirma As ComprobantesElectronicos.FirmarComprobante = New FirmarComprobante()

        Dim pahtCertificado = "AQUI VA LA RUTA DE LA FIRMA ELECTRONICA"
        Dim claveCertificado = "CLAVE DE LA FIRMA ELECTRONICA"
        Dim xmlFile As New System.Xml.XmlDocument()
        'xmlFile.Load(pathEjemploXML);
        Dim documentoxml As New System.Xml.XmlDocument()
        documentoxml.Load("ruta del archivo xml a firmar")
        objetoEntrada.ArchivoXML = documentoxml.InnerXml
        objetoEntrada.ClaveCertificado = claveCertificado
        objetoEntrada.PathCertificado = pahtCertificado

        Dim resultado = objetoFirma.FirmarDocumento(objetoEntrada)

        Dim XML_respuesta2 = resultado.ToString()

        Dim xDocumento As New Xml.XmlDocument

        xDocumento.LoadXml(resultado.ToString())
    End Sub
End Class
